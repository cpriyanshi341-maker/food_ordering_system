using FoodOrderingMVC.Models;

namespace FoodOrderingMVC.Data;

public static class SeedData
{
    public static void Initialize(AppDbContext db)
    {
        if (db.Categories.Any()) return;

        var starters = new Category { Name = "Starters" };
        var mains = new Category { Name = "Main Course" };
        var desserts = new Category { Name = "Desserts" };
        var drinks = new Category { Name = "Beverages" };

        db.Categories.AddRange(starters, mains, desserts, drinks);

        db.MenuItems.AddRange(
            new MenuItem { Name = "Paneer Tikka", Description = "Char-grilled cottage cheese with mint chutney", Price = 180, Icon = "🧆", Category = starters },
            new MenuItem { Name = "Veg Spring Rolls", Description = "Crispy rolls stuffed with seasoned vegetables", Price = 140, Icon = "🥟", Category = starters },
            new MenuItem { Name = "Masala Dosa", Description = "Crisp rice crepe with spiced potato filling", Price = 120, Icon = "🥞", Category = mains },
            new MenuItem { Name = "Veg Biryani", Description = "Fragrant basmati rice cooked with vegetables and spices", Price = 220, Icon = "🍛", Category = mains },
            new MenuItem { Name = "Margherita Pizza", Description = "Classic tomato, mozzarella and basil", Price = 260, Icon = "🍕", Category = mains },
            new MenuItem { Name = "Gulab Jamun", Description = "Warm milk dumplings in cardamom syrup", Price = 90, Icon = "🍮", Category = desserts },
            new MenuItem { Name = "Chocolate Brownie", Description = "Fudgy brownie served with ice cream", Price = 150, Icon = "🍫", Category = desserts },
            new MenuItem { Name = "Masala Chai", Description = "Ginger and cardamom milk tea", Price = 40, Icon = "☕", Category = drinks },
            new MenuItem { Name = "Fresh Lime Soda", Description = "Sweet or salted, chilled", Price = 60, Icon = "🍹", Category = drinks }
        );

        db.SaveChanges();
    }
}
