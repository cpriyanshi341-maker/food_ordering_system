using FoodOrderingMVC.Models;
using Microsoft.EntityFrameworkCore;

namespace FoodOrderingMVC.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Category> Categories => Set<Category>();
    public DbSet<MenuItem> MenuItems => Set<MenuItem>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderLine> OrderLines => Set<OrderLine>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<MenuItem>().Property(m => m.Price).HasPrecision(10, 2);
        modelBuilder.Entity<Order>().Property(o => o.Total).HasPrecision(10, 2);
        modelBuilder.Entity<OrderLine>().Property(l => l.UnitPrice).HasPrecision(10, 2);
        modelBuilder.Entity<OrderLine>().Ignore(l => l.LineTotal);
    }
}
