using FoodOrderingMVC.Data;
using FoodOrderingMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FoodOrderingMVC.Controllers;

public class OrdersController : Controller
{
    private readonly AppDbContext _db;
    public OrdersController(AppDbContext db) => _db = db;

    // Admin: list of all orders, optionally filtered by status.
    public async Task<IActionResult> Index(string? status)
    {
        var orders = await _db.Orders.Include(o => o.Lines).ToListAsync();
        if (!string.IsNullOrEmpty(status))
            orders = orders.Where(o => o.Status == status).ToList();

        ViewBag.Status = status;
        ViewBag.Revenue = orders.Where(o => o.Status != OrderStatus.Cancelled).Sum(o => o.Total);
        return View(orders.OrderByDescending(o => o.PlacedAt).ToList());
    }

    public async Task<IActionResult> Details(int id)
    {
        var order = await _db.Orders.Include(o => o.Lines).FirstOrDefaultAsync(o => o.Id == id);
        return order == null ? NotFound() : View(order);
    }

    public async Task<IActionResult> Confirmation(int id)
    {
        var order = await _db.Orders.Include(o => o.Lines).FirstOrDefaultAsync(o => o.Id == id);
        return order == null ? NotFound() : View(order);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> UpdateStatus(int id, string status)
    {
        var order = await _db.Orders.FindAsync(id);
        if (order == null) return NotFound();
        if (OrderStatus.All.Contains(status))
        {
            order.Status = status;
            await _db.SaveChangesAsync();
            TempData["Success"] = $"Order #{id} marked as '{status}'.";
        }
        return RedirectToAction(nameof(Details), new { id });
    }
}
