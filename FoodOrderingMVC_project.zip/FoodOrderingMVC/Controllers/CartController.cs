using FoodOrderingMVC.Data;
using FoodOrderingMVC.Helpers;
using FoodOrderingMVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace FoodOrderingMVC.Controllers;

public class CartController : Controller
{
    private const string CartKey = "cart";
    private readonly AppDbContext _db;
    public CartController(AppDbContext db) => _db = db;

    private List<CartItem> GetCart() => HttpContext.Session.GetObject<List<CartItem>>(CartKey) ?? new();
    private void SaveCart(List<CartItem> cart) => HttpContext.Session.SetObject(CartKey, cart);

    public IActionResult Index() => View(GetCart());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Add(int id, string? returnUrl)
    {
        var item = await _db.MenuItems.FindAsync(id);
        if (item == null || !item.IsAvailable) return NotFound();

        var cart = GetCart();
        var line = cart.FirstOrDefault(c => c.MenuItemId == id);
        if (line == null)
            cart.Add(new CartItem { MenuItemId = id, Name = item.Name, Icon = item.Icon, Price = item.Price, Quantity = 1 });
        else
            line.Quantity++;

        SaveCart(cart);
        TempData["Success"] = $"{item.Name} added to cart.";
        return !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)
            ? Redirect(returnUrl)
            : RedirectToAction("Index", "Home");
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Update(int id, int quantity)
    {
        var cart = GetCart();
        var line = cart.FirstOrDefault(c => c.MenuItemId == id);
        if (line != null)
        {
            if (quantity <= 0) cart.Remove(line);
            else line.Quantity = Math.Min(quantity, 50);
            SaveCart(cart);
        }
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Remove(int id)
    {
        var cart = GetCart();
        cart.RemoveAll(c => c.MenuItemId == id);
        SaveCart(cart);
        return RedirectToAction(nameof(Index));
    }

    public IActionResult Checkout()
    {
        if (!GetCart().Any()) return RedirectToAction(nameof(Index));
        ViewBag.Cart = GetCart();
        return View(new Order());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Checkout(Order order)
    {
        var cart = GetCart();
        if (!cart.Any()) return RedirectToAction(nameof(Index));

        ModelState.Remove(nameof(Order.Lines));
        if (!ModelState.IsValid)
        {
            ViewBag.Cart = cart;
            return View(order);
        }

        order.PlacedAt = DateTime.Now;
        order.Status = OrderStatus.Placed;
        order.Lines = cart.Select(c => new OrderLine
        {
            ItemName = c.Name,
            UnitPrice = c.Price,
            Quantity = c.Quantity
        }).ToList();
        order.Total = cart.Sum(c => c.LineTotal);

        _db.Orders.Add(order);
        await _db.SaveChangesAsync();

        HttpContext.Session.Remove(CartKey);
        return RedirectToAction("Confirmation", "Orders", new { id = order.Id });
    }
}
