using FoodOrderingMVC.Data;
using FoodOrderingMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace FoodOrderingMVC.Controllers;

/// <summary>Admin CRUD for menu items.</summary>
public class MenuController : Controller
{
    private readonly AppDbContext _db;
    public MenuController(AppDbContext db) => _db = db;

    private async Task LoadCategories(int? selected = null) =>
        ViewBag.Categories = new SelectList(await _db.Categories.OrderBy(c => c.Name).ToListAsync(), "Id", "Name", selected);

    public async Task<IActionResult> Index() =>
        View(await _db.MenuItems.Include(m => m.Category).OrderBy(m => m.Category!.Name).ThenBy(m => m.Name).ToListAsync());

    public async Task<IActionResult> Create()
    {
        await LoadCategories();
        return View(new MenuItem());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(MenuItem item)
    {
        ModelState.Remove(nameof(MenuItem.Category));
        if (!ModelState.IsValid)
        {
            await LoadCategories(item.CategoryId);
            return View(item);
        }
        _db.MenuItems.Add(item);
        await _db.SaveChangesAsync();
        TempData["Success"] = $"'{item.Name}' was added to the menu.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int id)
    {
        var item = await _db.MenuItems.FindAsync(id);
        if (item == null) return NotFound();
        await LoadCategories(item.CategoryId);
        return View(item);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, MenuItem item)
    {
        if (id != item.Id) return BadRequest();
        ModelState.Remove(nameof(MenuItem.Category));
        if (!ModelState.IsValid)
        {
            await LoadCategories(item.CategoryId);
            return View(item);
        }
        _db.Update(item);
        await _db.SaveChangesAsync();
        TempData["Success"] = $"'{item.Name}' was updated.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Delete(int id)
    {
        var item = await _db.MenuItems.Include(m => m.Category).FirstOrDefaultAsync(m => m.Id == id);
        return item == null ? NotFound() : View(item);
    }

    [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var item = await _db.MenuItems.FindAsync(id);
        if (item != null)
        {
            _db.MenuItems.Remove(item);
            await _db.SaveChangesAsync();
            TempData["Success"] = $"'{item.Name}' was removed.";
        }
        return RedirectToAction(nameof(Index));
    }
}
