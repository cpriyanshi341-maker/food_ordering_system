using FoodOrderingMVC.Data;
using FoodOrderingMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FoodOrderingMVC.Controllers;

public class HomeController : Controller
{
    private readonly AppDbContext _db;
    public HomeController(AppDbContext db) => _db = db;

    // Customer-facing menu, optionally filtered by category and search text.
    public async Task<IActionResult> Index(int? categoryId, string? q)
    {
        var query = _db.MenuItems.Include(m => m.Category).Where(m => m.IsAvailable);

        if (categoryId.HasValue)
            query = query.Where(m => m.CategoryId == categoryId);
        if (!string.IsNullOrWhiteSpace(q))
            query = query.Where(m => m.Name.Contains(q));

        ViewBag.Categories = await _db.Categories.OrderBy(c => c.Name).ToListAsync();
        ViewBag.SelectedCategory = categoryId;
        ViewBag.Query = q;

        return View(await query.OrderBy(m => m.Category!.Name).ThenBy(m => m.Name).ToListAsync());
    }

    public IActionResult Error() => View();
}
