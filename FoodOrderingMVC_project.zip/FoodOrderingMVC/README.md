# Spice Route Kitchen — Online Food Ordering System

ASP.NET Core MVC (.NET 8) web application with Entity Framework Core and SQLite.

**Prepared by:** Princy Choudhary
**Enrollment No.:** 202403103510266

## Features

- Browse the menu with category filter and search
- Session-based shopping cart (add, change quantity, remove)
- Checkout with server-side validation, creates an order with line items
- Order confirmation page
- Admin: full CRUD for menu items
- Admin: order list with status filter, revenue total, and status updates
- Database is created and seeded automatically on first run

## Architecture (MVC)

| Layer | Files |
|-------|-------|
| Models | `Category`, `MenuItem`, `Order`, `OrderLine`, `CartItem` |
| Views | Razor views in `Views/Home`, `Views/Menu`, `Views/Cart`, `Views/Orders` |
| Controllers | `HomeController`, `MenuController`, `CartController`, `OrdersController` |
| Data | `AppDbContext` (EF Core), `SeedData` |

## Run it

Requirements: [.NET 8 SDK](https://dotnet.microsoft.com/download)

```bash
cd FoodOrderingMVC
dotnet restore
dotnet run
```

Open the HTTPS URL printed in the console (for example `https://localhost:7xxx`).
A `food.db` SQLite file is created automatically.

## Visual Studio

Open the folder / `.csproj` in Visual Studio 2022, press **F5**.

## Pages

| URL | Purpose |
|-----|---------|
| `/` | Customer menu |
| `/Cart` | Cart |
| `/Cart/Checkout` | Checkout form |
| `/Menu` | Admin: manage dishes |
| `/Orders` | Admin: orders & revenue |
