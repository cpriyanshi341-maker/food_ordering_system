namespace FoodOrderingMVC.Models;

/// <summary>Cart line stored in the user's session (not in the database).</summary>
public class CartItem
{
    public int MenuItemId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Icon { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public int Quantity { get; set; }

    public decimal LineTotal => Price * Quantity;
}
