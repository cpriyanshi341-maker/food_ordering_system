using System.ComponentModel.DataAnnotations;

namespace FoodOrderingMVC.Models;

public class Order
{
    public int Id { get; set; }

    [Required, StringLength(80), Display(Name = "Full name")]
    public string CustomerName { get; set; } = string.Empty;

    [Required, Phone, Display(Name = "Phone number")]
    public string Phone { get; set; } = string.Empty;

    [Required, StringLength(250), Display(Name = "Delivery address")]
    public string Address { get; set; } = string.Empty;

    public DateTime PlacedAt { get; set; } = DateTime.Now;

    public string Status { get; set; } = OrderStatus.Placed;

    public decimal Total { get; set; }

    public List<OrderLine> Lines { get; set; } = new();
}

public class OrderLine
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public Order? Order { get; set; }

    public string ItemName { get; set; } = string.Empty;
    public decimal UnitPrice { get; set; }
    public int Quantity { get; set; }

    public decimal LineTotal => UnitPrice * Quantity;
}

public static class OrderStatus
{
    public const string Placed = "Placed";
    public const string Preparing = "Preparing";
    public const string OutForDelivery = "Out for delivery";
    public const string Delivered = "Delivered";
    public const string Cancelled = "Cancelled";

    public static readonly string[] All = { Placed, Preparing, OutForDelivery, Delivered, Cancelled };
}
