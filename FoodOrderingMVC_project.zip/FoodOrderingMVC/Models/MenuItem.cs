using System.ComponentModel.DataAnnotations;

namespace FoodOrderingMVC.Models;

public class MenuItem
{
    public int Id { get; set; }

    [Required, StringLength(80)]
    public string Name { get; set; } = string.Empty;

    [StringLength(250)]
    public string? Description { get; set; }

    [Range(1, 10000, ErrorMessage = "Price must be between 1 and 10000")]
    [DataType(DataType.Currency)]
    public decimal Price { get; set; }

    [Display(Name = "Emoji / Icon")]
    [StringLength(8)]
    public string Icon { get; set; } = "🍽️";

    [Display(Name = "Available")]
    public bool IsAvailable { get; set; } = true;

    [Display(Name = "Category")]
    public int CategoryId { get; set; }
    public Category? Category { get; set; }
}
